
package pizza;


public class Venda {

    public static void main(String[] args) {
        
        Pizza pizza1 = new Pizza();
pizza1.adicionaIngrediente(1, "Queijo");
pizza1.adicionaIngrediente(2, "Presunto");
pizza1.adicionaIngrediente(3, "Tomate");
pizza1.adicionaIngrediente(4, "Catupiry");
pizza1.adicionaIngrediente(5, "Frango");
pizza1.adicionaIngrediente(6, "Oregano");

Pizza pizza2 = new Pizza();
pizza2.adicionaIngrediente(1, "Queijo");
pizza2.adicionaIngrediente(2, "Presunto");

Pizza pizza3 = new Pizza();
pizza3.adicionaIngrediente(1, "Queijo");
pizza3.adicionaIngrediente(2, "Presunto");
pizza3.adicionaIngrediente(3, "Tomate");

CarrinhoDeCompras carrinho = new CarrinhoDeCompras();
carrinho.adicionaPizza(pizza1);
carrinho.adicionaPizza(pizza2);
carrinho.adicionaPizza(pizza3);


System.out.println("\nTotal: ................................. R$ " + carrinho.valorTotalPizzas());
    }
    
}

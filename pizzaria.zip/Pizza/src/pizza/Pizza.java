package pizza;

import java.util.HashMap;

public class Pizza {    
    public HashMap<Integer, String> ingredientes;        
    public Pizza() {
        this.ingredientes = new HashMap<>();        
    }    
    public void adicionaIngrediente(Integer id, String nome)
    {
        ingredientes.put(id, nome);        
    }   
    public int getPreco()
    {
        int result = 15;        
        if (getQuantidade()>=3 && getQuantidade()<=5)
        {
            result = 20;
        }
        else if (getQuantidade()>5)
        {
            result = 23;
        }
        return result;
    }    
    public Integer getQuantidade()
    {
        return ingredientes.size();
    }    
    
}

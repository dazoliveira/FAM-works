
package pizza;

import java.util.ArrayList;
public class CarrinhoDeCompras {
    public ArrayList<Pizza> pizzas;
    private int contador = 1;
    
    public CarrinhoDeCompras() {
        this.pizzas = new ArrayList<>();
    }    
    public void adicionaPizza(Pizza pizza)
    {
        if (pizza.getQuantidade()>0){
            this.pizzas.add(pizza);
        }
    }    
    public int valorTotalPizzas()
    {
        int result = 0;
        for(Pizza pizza: pizzas)
        {
            System.out.println("A pizza " + contador + " possui "+ pizza.getQuantidade() + " ingredientes e custa: R$ " + pizza.getPreco());
            result = result + pizza.getPreco();
            contador++;
        }
        return result;
    }
}
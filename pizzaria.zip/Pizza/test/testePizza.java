

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;
import pizza.CarrinhoDeCompras;
import pizza.Pizza;


public class testePizza {
    
    
    public testePizza() {

    }
    @Test
   public void testeValorPizza(){
        int valor = 0;
         Pizza pizza1 = new Pizza();
    pizza1.adicionaIngrediente(1, "Queijo");
    pizza1.adicionaIngrediente(2, "Presunto");
    pizza1.adicionaIngrediente(3, "Tomate");
   // pizza1.adicionaIngrediente(4, "Catupiry");
   // pizza1.adicionaIngrediente(5, "Frango");
   // pizza1.adicionaIngrediente(6, "Oregano");
    
    
    CarrinhoDeCompras carrinho = new CarrinhoDeCompras();
    carrinho.adicionaPizza(pizza1);
    valor = carrinho.valorTotalPizzas();
    assertEquals(10,valor);
   }
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
    }
    
    @After
    public void tearDown() {
    }

    // TODO add test methods here.
    // The methods must be annotated with annotation @Test. For example:
    //
    // @Test
    // public void hello() {}
}
